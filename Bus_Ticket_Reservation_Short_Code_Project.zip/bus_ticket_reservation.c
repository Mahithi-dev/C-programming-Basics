#include <stdio.h>

int seats[3] = {3, 3, 3};
int id[100], bus[100], active[100], n = 0;

char *routes[] = {
    "Hyderabad-Vijayawada",
    "Hyderabad-Warangal",
    "Hyderabad-Bengaluru"
};

void showBuses() {
    int i;
    for (i = 0; i < 3; i++)
        printf("%d. %s  Seats:%d\n", i+1, routes[i], seats[i]);
}

void book() {
    int b;
    showBuses();
    printf("Enter bus number: ");
    scanf("%d", &b);

    if (b < 1 || b > 3 || seats[b-1] == 0 || n == 100) {
        printf("Booking unavailable!\n");
        return;
    }

    id[n] = n + 101;
    bus[n] = b;
    active[n] = 1;
    seats[b-1]--;
    printf("Booked! Ticket ID: %d\n", id[n]);
    n++;
}

void view() {
    int i;
    for (i = 0; i < n; i++)
        if (active[i])
            printf("Ticket:%d Bus:%d\n", id[i], bus[i]);
}

void cancel() {
    int x, i;
    printf("Enter ticket ID: ");
    scanf("%d", &x);

    for (i = 0; i < n; i++)
        if (id[i] == x && active[i]) {
            active[i] = 0;
            seats[bus[i]-1]++;
            printf("Ticket cancelled!\n");
            return;
        }
    printf("Ticket not found!\n");
}

int main() {
    int ch;
    do {
        printf("\n1.Buses  2.Book  3.View  4.Cancel  5.Exit\n");
        scanf("%d", &ch);

        switch (ch) {
            case 1: showBuses(); break;
            case 2: book(); break;
            case 3: view(); break;
            case 4: cancel(); break;
            case 5: printf("Thank you!\n"); break;
            default: printf("Invalid choice!\n");
        }
    } while (ch != 5);

    return 0;
}